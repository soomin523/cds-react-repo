import React from "react";
import { Button } from "reactstrap";

const HeadTop = (props) => {

    const user = props.user;

    return (
        <div id="headtop">
            {   user === "" ?
            <div>
                <Button className="join" color="black">회원가입</Button>
                <Button className="login" color="black">로그인</Button>
            </div>
                :
            <div>
                <Button className="myPage" color="black">{user}님 환영합니다.</Button>
            </div>
            }
        </div>
    );
}

export default HeadTop;