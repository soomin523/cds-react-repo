import React from "react";

const HeadNav = (props) => {

    const setHover = props.setHover;
    const navhover = () => {
        setHover(true);
    }
    const navhoverout = () => {
        setHover(false);
    }

    return (
        <div className="navp">
            <h1>FitRoot</h1>
            <div>
                <div className="class"></div>
                <nav id="nav" onMouseOver={navhover} onMouseOut={navhoverout}>
                    <div className="navi">
                        <p>공지사항</p>
                        <i className="fa-solid fa-angle-down"></i>
                    </div>
                    <div className="navi">
                        <p>운동</p>
                        <i className="fa-solid fa-angle-down"></i>
                    </div>
                    <div className="navi">
                        <p>식단</p>
                        <i className="fa-solid fa-angle-down"></i>
                    </div>
                    <div className="navi">
                        <p>커뮤니티</p>
                        <i className="fa-solid fa-angle-down"></i>
                    </div>
                    <div className="navi">
                        <p>건강정보</p>
                        <i className="fa-solid fa-angle-down"></i>
                    </div>
                </nav>
            </div>
        </div>
    );
}

export default HeadNav;