import React from "react";

const HeadHiddenNav = (props) => {

    //hidden 숨기기
    const hidden = props.hidden;
    const setHidden = props.setHidden;
    const hover = props.hover;
    const hiddenStyle = {
        visibility: hover ? 'visible' : 
            hidden? 'hidden' : 'visible'
    }
    const hiddenOn = () => {
        setHidden(false);
    }
    const hiddenOff = () => {
        setHidden(true);
    }

    return (
        <nav id="hiddennav" style={hiddenStyle} onMouseOver={hiddenOn} onMouseOut={hiddenOff}>
            <div>
                <button>공지사항</button>
                <button>이벤트</button>
                <button>자주 묻는 질문</button>
            </div>
            <div>
                <button>이 주의 챌린지</button>
                <button>근력향상</button>
                <button>체형교정</button>
                <button>유연성</button>
                <button>다이어트</button>
            </div>
            <div>
                <button>다이어트 식단</button>
                <button>가족 건강식단</button>
                <button>영양 톡톡</button>
            </div>
            <div>
                <button>전체 인기글</button>
                <button>운동</button>
                <button>식단</button>
                <button>자유게시판</button>
            </div>
            <div>
                <button>건강 기록하기</button>
            </div>
        </nav>
    );
}

export default HeadHiddenNav;