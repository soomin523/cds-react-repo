import './Header.css';
import React, { useState } from "react";
import HeadTop from "./HeadTop";
import HeadNav from './HeadNav';
import HeadHiddenNav from './HeadHiddenNav';

const Header = () => {
    
    //user 이름
    const user = "abc";

    //hiddenNav 숨기기
    const [hidden, setHidden] = useState(true);
    const [hover, setHover] = useState(false); //true

    return (
        <header>
            <HeadTop user={user} />
            <HeadNav setHover={setHover} />
            <HeadHiddenNav hover={hover} hidden={hidden} setHidden={setHidden} />
        </header>
    );
}

export default Header;